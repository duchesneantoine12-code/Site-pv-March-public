-- =====================================================================
--  Marchés publics : crédits et dossiers d'achat
--  À exécuter une seule fois dans Supabase : SQL Editor > New query > Run
--  Toutes les tables commencent par mp_ : elles peuvent cohabiter avec
--  les tables d'un autre site dans le même projet.
-- =====================================================================

-- Personnes autorisées (une ligne par adresse e-mail)
create table if not exists public.mp_membres (
  email text primary key,
  ajoute_le timestamptz not null default now()
);

-- Profil de chaque utilisateur : nom affiché et thème choisi
create table if not exists public.mp_profils (
  id uuid primary key references auth.users (id) on delete cascade,
  nom text,
  theme text default ''
);

-- Exercices ouverts à l'avance (ex. 2027 avant le 1er janvier)
create table if not exists public.mp_exercices (
  annee text primary key check (annee ~ '^\d{4}$')
);

-- Crédits budgétaires
create table if not exists public.mp_credits (
  id uuid primary key default gen_random_uuid(),
  libelle text not null,
  annee text not null check (annee ~ '^\d{4}$'),
  montant numeric(14,2) not null default 0,
  reference text default '',
  catalogue text default '',
  notes text default '',
  created_at timestamptz not null default now(),
  created_by uuid references auth.users (id) on delete set null,
  updated_at timestamptz not null default now(),
  updated_by uuid references auth.users (id) on delete set null
);

-- Dossiers d'achat
create table if not exists public.mp_dossiers (
  id uuid primary key default gen_random_uuid(),
  numero text not null unique,
  date date not null,
  firme text default '',
  catalogue text default '',
  montant numeric(14,2),
  credit_id uuid references public.mp_credits (id) on delete set null,
  objet text default '',
  notes text default '',
  extras jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  created_by uuid references auth.users (id) on delete set null,
  updated_at timestamptz not null default now(),
  updated_by uuid references auth.users (id) on delete set null
);
create index if not exists mp_dossiers_credit_idx on public.mp_dossiers (credit_id);
create index if not exists mp_dossiers_date_idx on public.mp_dossiers (date);

-- ---------------------------------------------------------------------
--  Qui a encodé / modifié : rempli par la base, impossible à falsifier
-- ---------------------------------------------------------------------
create or replace function public.mp_trace() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    new.created_at := now();
    new.created_by := auth.uid();
  else
    new.created_at := old.created_at;
    new.created_by := old.created_by;
  end if;
  new.updated_at := now();
  new.updated_by := auth.uid();
  return new;
end $$;

drop trigger if exists mp_credits_trace on public.mp_credits;
create trigger mp_credits_trace before insert or update on public.mp_credits
  for each row execute function public.mp_trace();
drop trigger if exists mp_dossiers_trace on public.mp_dossiers;
create trigger mp_dossiers_trace before insert or update on public.mp_dossiers
  for each row execute function public.mp_trace();

-- ---------------------------------------------------------------------
--  Accès : seules les adresses présentes dans mp_membres voient et
--  modifient les données
-- ---------------------------------------------------------------------
create or replace function public.mp_est_membre() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.mp_membres
    where lower(email) = lower(coalesce(auth.jwt() ->> 'email', ''))
  );
$$;
grant execute on function public.mp_est_membre() to authenticated;

alter table public.mp_membres   enable row level security;
alter table public.mp_profils   enable row level security;
alter table public.mp_exercices enable row level security;
alter table public.mp_credits   enable row level security;
alter table public.mp_dossiers  enable row level security;

-- mp_membres : lecture par les membres, modification uniquement depuis Supabase
drop policy if exists mp_membres_lecture on public.mp_membres;
create policy mp_membres_lecture on public.mp_membres
  for select to authenticated using (public.mp_est_membre());

-- mp_profils : les membres voient les noms ; chacun gère son propre profil
drop policy if exists mp_profils_lecture on public.mp_profils;
create policy mp_profils_lecture on public.mp_profils
  for select to authenticated using (public.mp_est_membre() or id = auth.uid());
drop policy if exists mp_profils_creation on public.mp_profils;
create policy mp_profils_creation on public.mp_profils
  for insert to authenticated with check (id = auth.uid());
drop policy if exists mp_profils_modif on public.mp_profils;
create policy mp_profils_modif on public.mp_profils
  for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

-- Exercices, crédits, dossiers : tout pour les membres
drop policy if exists mp_exercices_membres on public.mp_exercices;
create policy mp_exercices_membres on public.mp_exercices
  for all to authenticated using (public.mp_est_membre()) with check (public.mp_est_membre());
drop policy if exists mp_credits_membres on public.mp_credits;
create policy mp_credits_membres on public.mp_credits
  for all to authenticated using (public.mp_est_membre()) with check (public.mp_est_membre());
drop policy if exists mp_dossiers_membres on public.mp_dossiers;
create policy mp_dossiers_membres on public.mp_dossiers
  for all to authenticated using (public.mp_est_membre()) with check (public.mp_est_membre());

-- ---------------------------------------------------------------------
--  Mise à jour en direct entre collègues (Realtime)
-- ---------------------------------------------------------------------
do $$
begin
  begin alter publication supabase_realtime add table public.mp_credits;   exception when others then null; end;
  begin alter publication supabase_realtime add table public.mp_dossiers;  exception when others then null; end;
  begin alter publication supabase_realtime add table public.mp_exercices; exception when others then null; end;
end $$;

-- ---------------------------------------------------------------------
--  À ADAPTER : ton adresse e-mail (et celles de tes collègues)
-- ---------------------------------------------------------------------
insert into public.mp_membres (email) values
  ('ton.adresse@exemple.be')
on conflict do nothing;
