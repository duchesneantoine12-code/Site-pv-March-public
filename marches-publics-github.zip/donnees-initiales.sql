-- =====================================================================
--  Reprise des données déjà encodées sur la version Claude
--  À exécuter APRÈS supabase.sql (SQL Editor > New query > Run)
--  Les champs « Encodé par » de ces lignes resteront vides.
-- =====================================================================

insert into public.mp_credits (id, libelle, annee, montant, reference, catalogue, notes) values
  ('7a1c2e40-0001-4c00-9000-000000000240', 'Catalogue 240', '2026', 1500, '', '240', 'Repris de l''ancien budget du catalogue 240.'),
  ('7a1c2e40-0001-4c00-9000-000000000256', 'Catalogue 256', '2026', 4000, '', '256', 'Repris de l''ancien budget du catalogue 256.')
on conflict (id) do nothing;

insert into public.mp_dossiers (numero, date, firme, catalogue, montant, credit_id, objet, notes) values
  ('6mk00254', '2026-11-11', 'leboutte', '240', 1500, '7a1c2e40-0001-4c00-9000-000000000240', 'fourniture de bureau', ''),
  ('6abyaeu',  '2026-11-12', 'lecot',    '256', 3500, '7a1c2e40-0001-4c00-9000-000000000256', '', '')
on conflict (numero) do nothing;

insert into public.mp_exercices (annee) values ('2027') on conflict do nothing;
